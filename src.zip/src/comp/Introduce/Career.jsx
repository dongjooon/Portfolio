function Career(){
    return(
        <div>
            <article>
                <h3>EDUCATION</h3><br/>
                <div>학사학위 컴퓨터공학</div>
                <div>가천대학교</div>
                <div>취득일자 : 2026년</div><br/><br/><br/><br/>
                <h3>LISENCE</h3>
                <div>정보처리기사(2025 취득)</div>
                <div>네트워크 관리사 2급(2024 취득)</div>
                <div>SQLD(2025 취득)</div>
                <div style={{position:"absolute",left:"390px", top:"0px"}} className="right">
                    <h3>SKILL</h3>
                    <div style={{fontSize:"8px", position:"absolute",left:"100px"}}>하</div>
                    <div style={{fontSize:"8px", position:"absolute",left:"190px" ,top:"60px"}}>상</div><br/>
                    <div className="skill">JAVA</div> <div className="skillbox1" style={{width:"70px"}}>&nbsp;</div> <div className="skillbox2">&nbsp;</div><br/>
                    <div className="skill">C++</div> <div className="skillbox1" style={{width:"55px"}}>&nbsp;</div> <div className="skillbox2">&nbsp;</div> <br />
                    <div className="skill">React</div> <div className="skillbox1" style={{width:"60px"}}>&nbsp;</div> <div className="skillbox2">&nbsp;</div> <br />
                    <div className="skill">DB Design</div> <div className="skillbox1" style={{width:"60px"}}>&nbsp;</div> <div className="skillbox2">&nbsp;</div> <br />
                    <div className="skill">SQL</div> <div className="skillbox1" style={{width:"75px"}}>&nbsp;</div> <div className="skillbox2">&nbsp;</div>
                    <br/><br/><br/>
                    <h3>WEBPAGE</h3>
                    <a href="https://blog.naver.com/odobuy1004" target="blank">Naver Blog</a><br/>
                    <a href="https://github.com/dongjooon" target="blank">Git Hub</a>
                </div>
            </article>
        </div>
    ) 
}
export default Career;