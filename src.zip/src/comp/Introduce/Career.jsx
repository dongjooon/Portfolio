import { Link } from "react-router-dom";
function Career(){
    return(
        <div>
            <h3>EDUCATION</h3>
            <div>학사학위 컴퓨터공학</div>
            <div>가천대학교</div>
            <div>취득일자 : 2026년</div>
            <h3>LISENCE</h3>
            <div>정보처리기사(2025 취득)</div>
            <div>네트워크 관리사 2급(2024 취득)</div>
            <div className="right">
                <h3>SKILL</h3>
                <div>JAVA</div>
                <div>C++</div>
                <div>React</div>
                <div>DB Design</div>
                <h3>WEBPAGE</h3>
                <Link to="https://blog.naver.com/odobuy1004">Naver Blog</Link><br/>
                <Link to="https://github.com/dongjooon">Git Hub</Link>
            </div>
            
        </div>
    ) 
}
export default Career;