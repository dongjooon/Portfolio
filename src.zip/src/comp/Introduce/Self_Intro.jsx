function Self_Intro(){
    return(
        <div>
            <article>
                <br/>   
                <img src="/photo.png" alt="no Img" width="120px" style={{border:"solid 1px white",borderRadius:"150px"}}></img>
                <div className="self" style={{fontSize:"20px", fontWeight:"bold",top:"20px"}}>다양한 프로젝트 경험</div>
                <div className="self" style={{top:"50px"}}>다수의 프로젝트 경험을 통해서 다른 사람들과 협력하여 목표를 달성하는 능력이 있다.</div> <br/>
                <div className="self" style={{fontSize:"20px", fontWeight:"bold", top:"120px"}}>열정적인 인재</div>
                <div className="self" style={{top:"150px"}}>문제를 해결하는 과정에서 포기하지 않고 성실하게 해결해 나가는 능력이 있다.</div><br/>
                <div style={{fontSize:"10px",position:"relative",left:"50px",bottom:"10px"}}>신동준</div>
                <div style={{fontSize:"10px",position:"relative",left:"40px",bottom:"10px"}}>2001.05.29</div>
                <table border="1px" style={{position:"relative",left:"140px"}}>
                    <tr><td>전화번호</td><td>010-9041-6852</td></tr>
                    <tr><td>이메일</td><td>odobuy1004@naver.com</td></tr>
                    <tr><td>주소</td><td>경기도 성남시 모란로 78번길 8-1 102호</td></tr>
                </table><br/>
                <div className="school">2008~2013 성수초등학교</div>
                <div className="school">2014~2016 수진중학교</div>
                <div className="school">2017~2019 성남고등학교</div>
                <div className="school">2020~2026 가천대학교</div>
            </article>
        </div>
    ) 
}
export default Self_Intro;