function Self_Intro(){
    return(
        <div>
            <h3>내</h3>
            <h3>설</h3>
            <h3>명</h3>
            <img alt="My Selfie"></img>
        </div>
    ) 
}
export default Self_Intro;