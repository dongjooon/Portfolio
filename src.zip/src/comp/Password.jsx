const Password = (props) => {
    const { pwd, changePwd } = props;
    return (
     <div>
      <div display='inline'>비밀번호</div>
      <input type="password" size="8" value={pwd} onChange={changePwd}/>
     </div>
    );
   };
   export default Password;