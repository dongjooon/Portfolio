function Motivation(){
    return(
        <div>
            <h3>지원 동기 :</h3>
        </div>
    ) 
}
export default Motivation;