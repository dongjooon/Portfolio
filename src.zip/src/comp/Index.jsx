const Index = () => {
    return (
        <div>
            <img src="/puppy.jpg" alt="No img" style={{position:"absolute", left:"350px", top:"250px", width:"350px", transform:"rotate(5deg)"}}></img>
            <img src="/dog.jpg" alt="No img" style={{position:"absolute", left:"900px", top:"230px", width:"350px", transform:"rotate(5deg)"}}></img>
            <div style={{position:"absolute", left:"620px", top:"180px",fontSize:"20px"}}>Let's Introduce About Dong Jun</div>
        </div>
    );
};
export default Index;    