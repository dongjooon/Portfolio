import { useState } from "react";
import Password from "./Password";
import { Routes, Route, Link } from "react-router-dom";
import Self_Intro from "./Introduce/Self_Intro";
import Career from "./Introduce/Career";

const Introduce = () => {
 const [pwd, setPwd] = useState("");
 const changePwd = (e) => {
  setPwd(e.target.value);
 };

 if (pwd === "1111") {
  return (
      <div>
        <hr/>
        <Link to="Self_Intro"> Self_Intro </Link> <br />
        <Link to="Career"> Career </Link> <br /> <hr />

        <Routes>
          <Route path="Self_Intro" Component={Self_Intro} />
          <Route path="Career" Component={Career} />
        </Routes>
      </div>
    );
 } else
  return (
   <Password pwd={pwd} changePwd={changePwd} />
  );
};
export default Introduce;