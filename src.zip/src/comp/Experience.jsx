import React from "react";
import { Routes, Route, Link } from "react-router-dom";
import Volunteer from "./Experience/Volunteer";
import Motivation from "./Experience/Motivation";
function Experience(){
    return (
        <div>
          <hr/>
          <Link to="Volunteer"> Volunteer </Link> <br />
          <Link to="Motivation"> Motivation </Link> <br /> <hr />
  
          <Routes>
            <Route path="Volunteer" Component={Volunteer} />
            <Route path="Motivation" Component={Motivation} />
          </Routes>
        </div>
      );
}
export default Experience;