function Contest1(){
    return(
        <div>
            <img src="../../image/contest1.jpg" alt="No img"></img>
        </div>
    ) 
}
export default Contest1;