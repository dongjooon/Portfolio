function Contest1(){
    return(
        <div>
            <article>
                <h3 style={{fontSize:"30px"}}>인디게임 페스티벌</h3><br/>
                <div className="con">
                    <b>주제</b> : 프로젝트 랜타디IP를 활용한 게임콘텐츠 응모<br/>
                </div>
                <div className="con">
                    Trading Card Game으로 프로젝트 랜타디의 캐릭터들을 <br/>
                </div>
                <div className="con">
                    카드의 요소로 하는 게임으로 응용<br/>
                </div>
                <div className="con">
                    턴제를 적용하여 PVE or PVP를 콘텐츠로 사용
                </div>
                <img src="/contest1.jpg" alt="No img" style={{position:"absolute", left:"430px", top:"10px"}}></img>
            </article>
            
        </div>
    ) 
}
export default Contest1;