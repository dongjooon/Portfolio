function Contest2(){
    return(
        <div>
            <article>
                <h3 style={{fontSize:"30px"}}>게임 공모전</h3><br/>
                <div className="con">
                    <b>주제</b> : 출시 이력이 없는 신규 게임 개발<br/>
                </div>
                <div className="con">
                    어드벤쳐 장르의 게임으로 청력과 작곡력을 <br/>
                </div>
                <div className="con">
                    잃어버린 음악가가 음표를 수집해서 자신의 <br/>
                </div>
                <div className="con">
                    음악을 완성시키면서 성장해 나가는 이야기로<br/>
                </div>
                <div className="con">
                    악보를 완성시 해당 노래가 오케스트라 <br/>
                </div>
                <div className="con">
                    형식으로 들리게 연출
                </div>
                <img src="/contest2.jpg" alt="No img" style={{position:"absolute", left:"430px", top:"10px"}}></img>
            </article>
        </div>
    ) 
}
export default Contest2;