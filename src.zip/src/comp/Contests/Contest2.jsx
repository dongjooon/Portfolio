function Contest2(){
    return(
        <div>
            <img src="../../image/contest2.jpg" alt="No img"></img>
        </div>
    ) 
}
export default Contest2;