function Project2(){
    return(
        <div>
            <h3>Project1</h3>
            <table border="1" className="prj1">
                <tr><td>Project Name</td><td>JAVA를 활용한 게임</td></tr>
                <tr><td>Project Period</td><td>2024.01~2024.02</td></tr>
                <tr><td>Project Member</td><td>3명</td></tr>
                <tr><td>Project Explanation</td><td>JAVA를 이용한 게임</td></tr>
                <tr><td>Project Role</td><td>게임 아이디어 구상 및 코드 작성</td></tr>
            </table>
        </div>
    ) 
}
export default Project2;