function Project2(){
    return(
        <div>
            <article>
            <h3>Project2</h3>
            <table border="1" style={{width:"420px"}}>
                <tr><td>Project Name</td><td>JAVA를 활용한 게임</td></tr>
                <tr><td>Project Period</td><td>2024.01~2024.02</td></tr>
                <tr><td>Project Member</td><td>3명</td></tr>
                <tr><td>Project Explanation</td><td>JAVA를 이용한 게임</td></tr>
                <tr><td>Project Role</td><td>게임 아이디어 구상 및 코드 작성</td></tr>
            </table><br/>
            <div className="gayo">프로젝트 개요 : </div>
            <div>JAVA를 이용하여 유명 게임인 포켓몬스터의 배틀을 구현 </div>
            <img src="/battle.jpg" alt="no img" style={{width:"250px" ,position:"relative",left:"440px", bottom:"160px"}}></img>
            </article>
            
        </div>
    ) 
}
export default Project2;