import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Contest from "./comp/Contest";
import Experience from "./comp/Experience";
import Introduce from "./comp/Introduce";
import Project from "./comp/Project";
import "./App.css";

function App() {
  return (
    <div className="App">
      <h1 style={{ textAlign: "center" }}>PORTFOLIO</h1>
      <Router>
        <div >
          <Link to="/Introduce" className="box">
            Introduce
          </Link>
          <br />
          <Link to="/Project" className="box">
          Project
          </Link>
          <br />
          <Link to="/Contest" className="box">
          Contest
          </Link>
          <br />
          <Link to="/Experience" className="box">
          Experience
          </Link>
        </div>

        <Routes>
          <Route path="/Introduce/*" Component={Introduce} />
          <Route path="/Project/*" Component={Project} />
          <Route path="/Contest/*" Component={Contest} />
          <Route path="/Experience/*" Component={Experience} />
        </Routes>
      </Router>
    </div>
  );
}
export default App;